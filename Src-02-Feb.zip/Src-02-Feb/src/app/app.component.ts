import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AngularAppDay2';
  isSelected=false;

  show=true;
  hide=false;

  colors=['Red','Green','Blue','Orange'];
  showHide(){
    this.hide=!this.hide;
  }
}
