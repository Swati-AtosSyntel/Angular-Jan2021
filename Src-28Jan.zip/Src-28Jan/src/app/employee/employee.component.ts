import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  day=1;
  hide=true;
  name:string="Swati";
  empObj={fname:"Aakash",lname:"Patil"};
  fullName:string;
  constructor() { 
    console.log("Angular Employee Componet Created...");
  }

  ngOnInit(): void {
    console.log("Angular Employee Componet initialized...");
  }
  ngOnDestory(){

  }

  GetFullName(){
    this.fullName=this.empObj.fname+this.empObj.lname;
  }

}
