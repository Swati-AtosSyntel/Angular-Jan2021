export class Repos {
    id: string;
    name: string;
    html_url: string;
    description: string;
  }