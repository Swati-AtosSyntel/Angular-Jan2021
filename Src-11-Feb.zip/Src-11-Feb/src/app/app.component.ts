import { Component } from '@angular/core';
import {HttpClient} from  '@angular/common/http';
import { Repos } from './Repos';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'httpClientApp';
  userName:string="Swati";
  baseUrl:string="https://api.github.com/";

  repos:Repos[];

constructor(public http:HttpClient){

}
ngOnInit() {
  //this.getRepos();
}

public getRepos(){
  return this.http.get<Repos[]>(this.baseUrl+'users/'+this.userName+'/repos')
  .subscribe(
    (response)=>{
      console.log('Response Received');
      console.log(response);
      this.repos=response;

    },
    (error)=>{
      console.error('Request failed');
      alert(error);
    },
    ()=>{
      console.log('Request Completed');
    }
  )
}





}
