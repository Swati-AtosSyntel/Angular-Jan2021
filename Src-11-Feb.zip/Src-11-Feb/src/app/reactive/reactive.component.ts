import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl} from '@angular/forms';
@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrls: ['./reactive.component.css']
})
export class ReactiveComponent implements OnInit {

  constructor() { }
  emailID;
  formdata;
  ngOnInit(): void {
    this.formdata=new FormGroup(
      {
        emailID:new FormControl("angular@yahoo.com"),
        pwd:new FormControl("AtosSyntel123")
      }
    );
  }
onClickSubmit(data){this.emailID=data.emailID};
}
